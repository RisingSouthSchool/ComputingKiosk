import math
a = 3
b = 2
x = math.ceil((a+b)/b)
print(x)